導入手順は同梱のフォルダを参照してください。
下記三点が必要となりますが、プレイヤーの顔見る機能が無くてもよいならば、FinalIKのみ任意です。


① VRCSDK3
② UdonSharp
③ FinalIK


CC0の提供となります。
ご自由にお使いください。

CC0 1.0 Universal (CC0 1.0)
Public Domain Dedication
https://creativecommons.org/publicdomain/zero/1.0/deed.ja